# 🌱 Mi huerto virtual

Simulación interactiva educativa de diez días. Los estudiantes eligen un cultivo (tomate, zanahoria o girasol) y toman decisiones sobre el agua, las horas de luz y el cuidado con abono. La salud de la planta varía y se muestra un registro diario.

## Cómo jugar

1. Abre `index.html` en cualquier navegador moderno.
2. Selecciona una planta y elige sus cuidados.
3. Pulsa **Avanzar un día** hasta completar diez días o hasta que la salud llegue a cero.
4. Revisa tus resultados y prueba otras decisiones con **Reiniciar**.

## Publicación gratis con GitHub Pages

1. Crea un repositorio nuevo en GitHub (por ejemplo, `mi-huerto-virtual`).
2. Descomprime el ZIP y sube los archivos `index.html` y `README.md` **a la raíz** del repositorio (no la carpeta contenedora).
3. En el repositorio abre **Settings → Pages**.
4. En **Build and deployment**, selecciona **Deploy from a branch**, rama **main**, carpeta **/(root)** y guarda.
5. Una vez que GitHub complete el despliegue, abre la URL que aparezca en Pages (normalmente `https://TU-USUARIO.github.io/mi-huerto-virtual/`).

No necesitas instalar librerías, servidor, base de datos ni usar claves. Funciona también sin conexión después de descargarlo.

## Nota pedagógica

La puntuación de salud es un modelo didáctico simplificado; no pretende representar las necesidades agronómicas exactas de cada especie. Se recomienda debatir las diferencias reales entre cultivos.
